
// Re-export from our hooks folder
import { useToast, toast } from "@/hooks/use-toast";

export { useToast, toast };
